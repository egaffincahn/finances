#' @title Get current date
#'
#' @return Each of the \code{currentX} functions return an integer.
#'   \code{componentsToDate} returns a \code{POSIXct}.
#'
#' @name CurrentDate
#'

#' @export
#' @rdname CurrentDate
currentDay <- function() {
    as.numeric(format(Sys.Date(), "%d"))
}

#' @export
#' @rdname CurrentDate
currentMonth <- function() {
    as.numeric(format(Sys.Date(), "%m"))
}

#' @export
#' @rdname CurrentDate
currentYear <- function() {
    as.numeric(format(Sys.Date(), "%Y"))
}

#' @export
#' @rdname CurrentDate
componentsToDate <- function(yr = currentYear(), mo = currentMonth(), dy = currentDay()) {
    as.POSIXct(paste(mo, dy, yr, sep = "/"), format = "%m/%d/%Y")
}
